+++
tags = ["documentat'n", "tutorrrial"]
title = "Tags"
weight = 40
+++
{{< piratify >}}