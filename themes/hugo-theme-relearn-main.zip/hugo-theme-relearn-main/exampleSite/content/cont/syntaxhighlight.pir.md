+++
title = "Code highlight'n"
weight = 16
+++
{{< piratify >}}