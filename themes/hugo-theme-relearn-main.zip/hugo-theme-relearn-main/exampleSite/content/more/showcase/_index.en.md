+++
title = "Showcase"
+++

## [GoboLinux Wiki](https://wiki.gobolinux.org/) by NEONsys.org

![GoboLinux image](images/gobolinux.png?width=60pc&classes=shadow)
## [BITS](https://bits-training.de/training/) by Dr. Lutz Gollan

![BITS image](images/bits-train.png?width=60pc&classes=shadow)
