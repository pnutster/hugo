+++
description = "This is a non-hidden demo child page of a hidden parent page"
tags = ["children", "hidden"]
title = "page 1-1-1-1"
+++

This is a **non-hidden** demo child page of a hidden parent page with a hidden child. You can still access the hidden child [directly]({{% relref "shortcodes/children/children-1/children-1-1/children-1-1-1/children-1-1-1-1/children-1-1-1-1-1" %}}) or via the search.

## Subpages of this page

{{% children showhidden="true" %}}
