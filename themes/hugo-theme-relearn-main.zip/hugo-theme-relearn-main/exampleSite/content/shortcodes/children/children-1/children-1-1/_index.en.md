+++
alwaysopen = false
description = "This is a demo child page"
tags = ["children", "non-hidden"]
title = "page 1-1"
+++

This is a demo child page with a hidden child. You can still access the hidden child [directly]({{% relref "shortcodes/children/children-1/children-1-1/children-1-1-1" %}}) or via the search.

## Subpages of this page

{{% children showhidden="true" %}}
