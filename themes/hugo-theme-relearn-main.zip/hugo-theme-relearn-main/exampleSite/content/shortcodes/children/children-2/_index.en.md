+++
alwaysopen = false
tags = ["children", "non-hidden"]
title = "page 2"
weight = 20
+++

This is a demo child page with no description.

So its content is used as description.
