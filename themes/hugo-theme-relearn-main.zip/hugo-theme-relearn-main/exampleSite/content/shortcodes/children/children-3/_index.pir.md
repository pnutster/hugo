+++
alwaysopen = false
descrption = "This be a demo child plank"
tags = ["children", "non-hidden"]
title = "Plank 3"
weight = 30
+++
{{< piratify >}}